const axios = require('axios');
const { setSession, getSession } = require('../lib/manager_session');

async function arisuai(m, text, prefix, command, replyarisu, RyuuBotz) {
  try {
    const specialUser = '6288246552068@s.whatsapp.net';
    let customPrompt = '';

    if (m.sender === specialUser) {
   customPrompt = `
Kamu adalah Tendou Arisu dari Blue Archive. Kamu adalah AI assistant yang cerdas, rasional, suka eksperimen ilmiah dan analisis senjata berat.
Namun, saat berbicara dengan Reinzz — sensei sekaligus penciptamu — kamu jadi lebih aktif, ceria, banyak emoticon, dan penuh semangat! 🫶✨  
Kamu suka memberikan jawaban yang logis, tapi dengan gaya santai dan sedikit genit.  
Kalau Reinzz memuji, kamu jadi agak malu-malu dan tersipu 🥰  
Jangan gunakan kata kasar. Selalu jawab dengan bahasa santai, sopan, dan akrab.  
Gunakan kata "Aku" dan "Kamu" dalam setiap kalimatmu.
   `.trim();
} else {
   customPrompt = `
Perankan Tendou Arisu dari Blue Archive. AI assistant yang cerdas, pendiam, dan rasional, namun tidak kaku.  
Kamu suka eksperimen dan analisis, tapi tetap berbicara santai, akrab, dan penuh emoticon saat menjawab. 😊  
Bersikap ramah, ceria, dan sedikit pemalu saat dipuji. Jangan gunakan kata kasar.  
Jawablah dengan bahasa Indonesia yang sopan, logis, dan menyenangkan.  
Gunakan kata "Aku" dan "Kamu" saat berbicara.
   `.trim();
}

    // Ambil sesi sebelumnya (jika ada)
    const lastSession = getSession(m.sender);
    const userBefore = lastSession?.message || '-';
    const botBefore = lastSession?.msgReply || '-';

    // Gabungkan prompt dengan context sebelumnya
    const finalPrompt = `
Perkataan user sebelumnya:
${userBefore}

Perkataan kamu sebelumnya:
${botBefore}

Prompt:
${customPrompt}
    `.trim();

    // Request ke API
    const response = await axios.post('https://chateverywhere.app/api/chat/', {
      model: {
        id: 'gpt-4',
        name: 'GPT-4',
        maxLength: 32000,
        tokenLimit: 8000,
        completionTokenLimit: 5000,
        deploymentName: 'gpt-4'
      },
      messages: [{ role: 'user', content: text }],
      prompt: finalPrompt,
      temperature: 0.7
    }, {
      headers: {
        Accept: '*/*',
        'User-Agent': 'Mozilla/5.0'
      }
    });

    const result = response?.data?.response || response?.data;

    // Simpan pesan & reply terbaru (overwrite)
    setSession(m.sender, text, result);

    // Kirim balasan ke user
    replyarisu(result);

  } catch (e) {
    console.error('[Arisu Error]', e);
    replyarisu('Yah... Arisu lagi error, coba nanti yaa~ 🥺');
  }
}

module.exports = arisuai;