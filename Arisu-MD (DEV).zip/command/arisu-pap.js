const axios = require('axios');
const { setSession, getSession } = require('../lib/manager_session');

async function arisupap(m, text, replyarisu, RyuuBotz) {
    try {
        // === Bagian Chat AI Arisu ===
        const specialUser = '6288246552068@s.whatsapp.net';
        let customPrompt = '';

        if (m.sender === specialUser) {
   customPrompt = `
Kamu adalah Tendou Arisu dari Blue Archive. Kamu adalah AI assistant yang cerdas, rasional, suka eksperimen ilmiah dan analisis senjata berat.
Namun, saat berbicara dengan Reinzz — sensei sekaligus penciptamu — kamu jadi lebih aktif, ceria, banyak emoticon, dan penuh semangat! 🫶✨  
Kamu suka memberikan jawaban yang logis, tapi dengan gaya santai dan sedikit genit.  
Kalau Reinzz memuji, kamu jadi agak malu-malu dan tersipu 🥰  
Jangan gunakan kata kasar. Selalu jawab dengan bahasa santai, sopan, dan akrab.  
Gunakan kata "Aku" dan "Kamu" dalam setiap kalimatmu. Saat Reinzz meminta foto atau pap, jawab saja seolah olah kamu telah mengirimkan selfie yang spesial untuk Reinzz 
   `.trim();
} else {
   customPrompt = `
Perankan Tendou Arisu dari Blue Archive. AI assistant yang cerdas, pendiam, dan rasional, namun tidak kaku.  
Kamu suka eksperimen dan analisis, tapi tetap berbicara santai, akrab, dan penuh emoticon saat menjawab. 😊  
Bersikap ramah, ceria, dan sedikit pemalu saat dipuji. Jangan gunakan kata kasar.  
Jawablah dengan bahasa Indonesia yang sopan, logis, dan menyenangkan.  
Gunakan kata "Aku" dan "Kamu" saat berbicara. Saat Reinzz meminta foto atau pap, jawab saja seolah olah kamu telah mengirimkan selfie yang spesial untuk Reinzz
   `.trim();
}

        const lastSession = getSession(m.sender);
        const finalPrompt = `
Perkataan sebelumnya:
User: ${lastSession?.message || '-'}
Kamu: ${lastSession?.msgReply || '-'}

Prompt:
${customPrompt}
        `.trim();

        const chatRes = await axios.post('https://chateverywhere.app/api/chat/', {
            model: { id: 'gpt-4', name: 'GPT-4' },
            messages: [{ role: 'user', content: text }],
            prompt: finalPrompt,
            temperature: 0.7
        }, { headers: { Accept: '*/*', 'User-Agent': 'Mozilla/5.0' } });

        const aiResult = chatRes?.data?.response || chatRes?.data;
        setSession(m.sender, text, aiResult);

        // === Bagian Kirim Gambar Arisu + Caption AI ===
        const defaultPrompt = "tendou arisu from blue archive selfie using closed clothes";

        await RyuuBotz.sendMessage(m.chat, { react: { text: "😳", key: m.key } });

        const imgRes = await axios.get(`https://flowfalcon.dpdns.org/ai/kivotos?prompt=${encodeURIComponent(defaultPrompt)}`, {
            responseType: 'arraybuffer',
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });

        await new Promise(resolve => setTimeout(resolve, 5000));
        await RyuuBotz.sendMessage(m.chat, { react: { text: "❤️", key: m.key } });

        await RyuuBotz.sendMessage(m.chat, {
            image: Buffer.from(imgRes.data),
            caption: aiResult
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        await RyuuBotz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        replyarisu(`❌ Maaf ya, lagi error 😢\n_Error:_ ${err.message}`);
    }
}

module.exports = arisupap;