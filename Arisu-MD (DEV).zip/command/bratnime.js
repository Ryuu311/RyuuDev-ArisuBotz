// ./command/bratnime.js
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const { createCanvas, loadImage, registerFont } = require('@napi-rs/canvas');
const sharp = require('sharp');

module.exports = async function bratnime(RyuuBotz, m, text, reply) {
    if (!text) return reply('Masukkan teks untuk stiker.');

    await RyuuBotz.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });

    try {
        let imageUrl = 'https://files.catbox.moe/kwkiyb.png';
        let fontUrl = 'https://github.com/googlefonts/noto-emoji/raw/main/fonts/NotoColorEmoji.ttf';
        let imagePath = path.join(__dirname, '../session/file.jpg');
        let outputPath = path.join(__dirname, '../session/file.webp');
        let fontPath = path.join(__dirname, '../session/NotoColorEmoji.ttf');

        if (!fs.existsSync(fontPath)) {
            let fontData = await axios.get(fontUrl, { responseType: 'arraybuffer' });
            fs.writeFileSync(fontPath, Buffer.from(fontData.data));
        }

        let response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        fs.writeFileSync(imagePath, Buffer.from(response.data));

        let baseImage = await loadImage(imagePath);
        let canvas = createCanvas(baseImage.width, baseImage.height);
        let ctx = canvas.getContext('2d');

        ctx.drawImage(baseImage, 0, 0, canvas.width, canvas.height);

        registerFont(fontPath, { family: 'EmojiFont' });

        let boardX = canvas.width * 0.18;
        let boardY = canvas.height * 0.57;
        let boardWidth = canvas.width * 0.56;
        let boardHeight = canvas.height * 0.25;

        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        let maxFontSize = 62;
        let minFontSize = 12;
        let fontSize = maxFontSize;

        function isTextFit(text, fontSize) {
            ctx.font = `bold ${fontSize}px EmojiFont`;
            let words = text.split(' ');
            let lineHeight = fontSize * 1.2;
            let maxWidth = boardWidth * 0.9;
            let lines = [];
            let currentLine = words[0];

            for (let i = 1; i < words.length; i++) {
                let testLine = currentLine + ' ' + words[i];
                let testWidth = ctx.measureText(testLine).width;
                if (testWidth > maxWidth) {
                    lines.push(currentLine);
                    currentLine = words[i];
                } else {
                    currentLine = testLine;
                }
            }
            lines.push(currentLine);
            let textHeight = lines.length * lineHeight;
            return textHeight <= boardHeight * 0.9;
        }

        while (!isTextFit(text, fontSize) && fontSize > minFontSize) {
            fontSize -= 2;
        }

        ctx.font = `bold ${fontSize}px EmojiFont`;

        let words = text.split(' ');
        let lineHeight = fontSize * 1.2;
        let maxWidth = boardWidth * 0.9;
        let lines = [];
        let currentLine = words[0];

        for (let i = 1; i < words.length; i++) {
            let testLine = currentLine + ' ' + words[i];
            let testWidth = ctx.measureText(testLine).width;
            if (testWidth > maxWidth) {
                lines.push(currentLine);
                currentLine = words[i];
            } else {
                currentLine = testLine;
            }
        }
        lines.push(currentLine);

        let startY = boardY + boardHeight / 2 - (lines.length - 1) * lineHeight / 2;
        lines.forEach((line, i) => {
            let xPos = boardX + boardWidth / 2 - 15;
            let yPos = startY + i * lineHeight;
            ctx.lineWidth = 3;
            ctx.strokeStyle = '#000000';
            ctx.strokeText(line, xPos, yPos);
            ctx.fillStyle = '#000000';
            ctx.fillText(line, xPos, yPos);
        });

        let buffer = canvas.toBuffer('image/jpeg');
        fs.writeFileSync(imagePath, buffer);
        await sharp(imagePath).toFormat('webp').toFile(outputPath);

        let bufffer = fs.readFileSync(outputPath);
await RyuuBotz.sendImageAsSticker(m.chat, bufffer, m, {
    packname: global.packname,
    author: global.author
}, { quoted: m });

    } catch (e) {
        console.error(e);
        reply(`⚠️ Terjadi kesalahan saat membuat stiker\n Error: ${e.message}`);
    }
}