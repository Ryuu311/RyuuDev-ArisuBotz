// ./command/bratnime-vid.js
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const { createCanvas, loadImage, registerFont } = require('canvas');
const sharp = require('sharp');
const { exec } = require('child_process');

module.exports = async function bratnimeVid(RyuuBotz, m, text, reply) {
    if (!text) return reply('Masukkan teks untuk stiker.');

    await RyuuBotz.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });

    try {
        let imageUrl = 'https://files.catbox.moe/kwkiyb.png';
        let fontUrl = 'https://github.com/googlefonts/noto-emoji/raw/main/fonts/NotoColorEmoji.ttf';
        let imagePath = path.join(__dirname, '../session/file.jpg');
        let fontPath = path.join(__dirname, '../session/NotoColorEmoji.ttf');
        let outputMp4 = path.join(__dirname, `../session/output_${Date.now()}.mp4`);
        let outputWebP = path.join(__dirname, `../session/animated_${Date.now()}.webp`);
        let frameDir = path.join(__dirname, `../session/frames_${Date.now()}`);

        if (!fs.existsSync(frameDir)) fs.mkdirSync(frameDir);

        if (!fs.existsSync(fontPath)) {
            let fontData = await axios.get(fontUrl, { responseType: 'arraybuffer' });
            fs.writeFileSync(fontPath, Buffer.from(fontData.data));
        }

        let response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        fs.writeFileSync(imagePath, Buffer.from(response.data));

        let baseImage = await loadImage(imagePath);
        let canvas = createCanvas(baseImage.width, baseImage.height);
        let ctx = canvas.getContext('2d');

        registerFont(fontPath, { family: 'EmojiFont' });

        let boardX = canvas.width * 0.17;
        let boardY = canvas.height * 0.57;
        let boardWidth = canvas.width * 0.56;
        let boardHeight = canvas.height * 0.25;

        ctx.textAlign = 'center';
        ctx.fillStyle = '#000000';
        ctx.textBaseline = 'middle';

        let maxFontSize = 62;
        let minFontSize = 12;
        let fontSize = maxFontSize;

        function isTextFit(text, fontSize) {
            ctx.font = `bold ${fontSize}px EmojiFont`;
            let words = text.split(' ');
            let lineHeight = fontSize * 1.2;
            let maxWidth = boardWidth * 0.9;
            let lines = [];
            let currentLine = words[0];

            for (let i = 1; i < words.length; i++) {
                let testLine = currentLine + ' ' + words[i];
                let testWidth = ctx.measureText(testLine).width;
                if (testWidth > maxWidth) {
                    lines.push(currentLine);
                    currentLine = words[i];
                } else {
                    currentLine = testLine;
                }
            }
            lines.push(currentLine);
            let textHeight = lines.length * lineHeight;
            return textHeight <= boardHeight * 0.9;
        }

        while (!isTextFit(text, fontSize) && fontSize > minFontSize) {
            fontSize -= 2;
        }

        ctx.font = `bold ${fontSize}px EmojiFont`;

        let words = text.split(' ');
        let lineHeight = fontSize * 1.2;
        let maxWidth = boardWidth * 0.9;
        let frames = [];

        for (let i = 1; i <= words.length; i++) {
            let tempText = words.slice(0, i).join(' ');
            let frameCanvas = createCanvas(baseImage.width, baseImage.height);
            let frameCtx = frameCanvas.getContext('2d');

            frameCtx.drawImage(baseImage, 0, 0, frameCanvas.width, frameCanvas.height);
            frameCtx.fillStyle = '#000000';
            frameCtx.textAlign = 'center';
            frameCtx.textBaseline = 'middle';
            frameCtx.font = `bold ${fontSize}px EmojiFont`;

            let lines = [];
            let currentLine = '';
            tempText.split(' ').forEach((word) => {
                let testLine = currentLine ? currentLine + ' ' + word : word;
                let testWidth = frameCtx.measureText(testLine).width;
                if (testWidth > maxWidth) {
                    lines.push(currentLine);
                    currentLine = word;
                } else {
                    currentLine = testLine;
                }
            });
            lines.push(currentLine);

            let startY = boardY + boardHeight / 2 - (lines.length - 1) * lineHeight / 2;
            lines.forEach((line, index) => {
                frameCtx.fillText(line, boardX + boardWidth / 2, startY + index * lineHeight);
            });

            let framePath = path.join(frameDir, `frame${i}.png`);
            fs.writeFileSync(framePath, frameCanvas.toBuffer('image/png'));
            frames.push(framePath);
        }

        exec(`ffmpeg -y -framerate 2 -i ${frameDir}/frame%d.png -c:v libx264 -pix_fmt yuv420p ${outputMp4}`, async (err) => {
            if (err) {
                console.error("❌ Error membuat video:", err);
                return reply("Terjadi kesalahan saat membuat video animasi.");
            }

            exec(`ffmpeg -i ${outputMp4} -vf "scale=512:512:flags=lanczos,format=rgba" -loop 0 -preset default -an -vsync 0 ${outputWebP}`, async (err) => {
                if (err) {
                    console.error("❌ Error konversi video ke stiker:", err);
                    return reply("Terjadi kesalahan saat mengonversi video ke stiker.");
                }

                await RyuuBotz.sendMessage(m.chat, { sticker: { url: outputWebP } }, { quoted: m });

                setTimeout(() => {
                    try {
                        fs.unlinkSync(imagePath);
                        fs.unlinkSync(outputMp4);
                        fs.unlinkSync(outputWebP);
                        fs.rmSync(frameDir, { recursive: true, force: true });
                    } catch (err) { console.error(err); }
                }, 5000);
            });
        });

    } catch (e) {
        console.error(e);
        reply('⚠️ Terjadi kesalahan saat membuat stiker.');
    }
};